"""
Examples and Demonstrations
==========================

Example scripts and demonstrations of the preprocessing pipeline.
"""

# Examples are standalone scripts - import as needed
